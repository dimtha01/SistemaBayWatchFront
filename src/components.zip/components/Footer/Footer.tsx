import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <footer className="bg-black text-gray-300 py-12 md:py-10">
      <div className="container mx-auto px-4 md:px-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Columna 1: Logo y Descripción */}
        <div className="flex flex-col items-start justify-center">
        <Link
          to="/"
          className="text-white text-2xl font-bold hover:opacity-90 transition-opacity"
        >
          <img
            src="/images/baywatch_logo.png"
            alt="Bay Watch Logo"
            className="h-24 w-auto"
          />
        </Link>
          <p className="text-sm leading-relaxed">
            Tu refugio perfecto para experiencias inolvidables. Descubre el lujo y la comodidad en cada
            estancia.
          </p>
          
        </div>

        {/* Columna 3: Contacto */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Contacto</h3>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              
              <span className="text-gray-400">123 Calle Principal, Ciudad, País</span>
            </div>
            <div className="flex items-center gap-2">
              
              <span className="text-gray-400">+1 (234) 567-8900</span>
            </div>
            <div className="flex items-center gap-2">
              
              <span className="text-gray-400">info@hotelv0.com</span>
            </div>
          </div>
        </div>

        {/* Columna 4: Newsletter (Opcional) */}
        <div>
          <h3 className="text-lg font-semibold text-white mb-4">Suscribete</h3>
          <p className="text-sm text-gray-400 mb-4">
            Suscríbete para recibir nuestras últimas ofertas y noticias.
          </p>
          <form className="flex gap-2 ">
            <input 
              type="email" 
              placeholder="Tu correo electrónico"
              className="flex-1 px-4 py-2 rounded-md bg-white text-black border border-gray-700 focus:outline-none focus:ring-2 focus:ring-[#0D0D0D]/40" 
            />
            <button 
              type="submit"
              className="bg-gradient-to-r from-[#F20C0C] via-[#D10000] to-[#A00000] text-white px-4 py-2 rounded-md hover:bg-orange-600 transition-colors"
            >
              Suscribir
            </button>
          </form>
          <div className="flex gap-4 mt-6 items-end-safe">
            <a 
              href="#" 
              className="text-gray-400 hover:text-orange-500 transition-colors" 
              aria-label="Facebook"
            >
              FB
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-orange-500 transition-colors" 
              aria-label="Twitter"
            >
              TW
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-orange-500 transition-colors"
              aria-label="Instagram"
            >
              IG
            </a>
            <a 
              href="#" 
              className="text-gray-400 hover:text-orange-500 transition-colors" 
              aria-label="YouTube"
            >
              YT
            </a>
          </div>
        </div>
      </div>

      {/* Derechos de Autor */}
      <div className="border-t border-gray-800 mt-4 pt-4 text-center text-sm text-gray-500">
        <p>&copy; 2025 Hotel BayWatch. Todos los derechos reservados.</p>
      </div>
    </footer>
  );
}