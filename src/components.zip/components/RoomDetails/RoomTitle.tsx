export const RoomTitle = () => (
  <>
    <h1 className="text-4xl font-bold mb-4">Suite Ocean View Premium</h1>
    <div className="flex items-center text-gray-600 mb-6">
      <div className="flex text-yellow-400 mr-2">
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star"></i>
        <i className="fas fa-star-half-alt"></i>
      </div>
      <span>4.9 (120 reseñas)</span>
      <span className="mx-3">•</span>
      <span><i className="fas fa-map-marker-alt mr-1"></i>Piso 12, Vista al Mar</span>
    </div>
  </>
);