export const Description = () => (
  <div className="bg-white rounded-lg shadow-md p-6 mb-8 transition-all hover:shadow-lg">
    <h2 className="text-2xl font-bold mb-4 text-gray-800">Descripción</h2>
    <div className="space-y-4">
      <p className="text-gray-700 leading-relaxed opacity-0 animate-fadeIn [animation-delay:100ms]">
        Sumérgete en el lujo y la comodidad...
      </p>
      <p className="text-gray-700 leading-relaxed opacity-0 animate-fadeIn [animation-delay:300ms]">
        Cada detalle ha sido cuidadosamente seleccionado...
      </p>
    </div>
  </div>
);