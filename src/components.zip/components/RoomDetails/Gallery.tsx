import { useState } from "react";

export const Gallery = () => {
  const [mainImage, setMainImage] = useState("/public/images/sobre nosotros banner.jpg");
  const thumbnails = ["Dormitorio", "Baño", "Sala de Estar", "Balcón"];

  return (
    <div className="mb-8">
      {/* Imagen principal con efecto de zoom al hover */}
      <div className="group relative overflow-hidden rounded-lg shadow-lg mb-4">
        <img
          src={mainImage}
          alt="Suite Ocean View Premium"
          className="w-full h-[450px] object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      </div>

      {/* Thumbnails interactivos */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {thumbnails.map((alt, idx) => (
          <button
            key={idx}
            onClick={() => setMainImage(`/public/images/sobre nosotros banner.jpg`)}
            className={`relative overflow-hidden rounded-lg shadow-md transition-all duration-300 ${
              mainImage === `/public/images/sobre nosotros banner.jpg` 
                ? "ring-2 ring-baywatch-orange scale-95" 
                : "hover:scale-95"
            }`}
          >
            <img
              src={`/public/images/sobre nosotros banner.jpg`}
              alt={alt}
              className="w-full h-28 sm:h-32 object-cover"
            />
            <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity">
              <span className="text-white font-medium text-sm bg-black/50 px-2 py-1 rounded">
                {alt}
              </span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};