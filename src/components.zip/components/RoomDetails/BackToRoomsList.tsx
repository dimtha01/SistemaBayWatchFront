export const BackToRoomsLink = () => (
  <div className="mb-6">
    <a 
      href="/habitaciones" 
      className="inline-flex items-center text-gray-600 hover:text-baywatch-red transition-colors duration-300 group"
    >
      <i className="fas fa-arrow-left mr-2 transition-transform duration-300 group-hover:-translate-x-1"></i>
      <span className="text-sm"> Volver a Habitaciones</span>
    </a>
  </div>
);