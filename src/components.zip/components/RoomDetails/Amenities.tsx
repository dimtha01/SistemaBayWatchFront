export const Amenities = () => {
  const items = [
    ["fas fa-wifi", "Wi-Fi de alta velocidad"],
    ["fas fa-tv", "Smart TV con cable"],
    // ... resto de items
  ];

  return (
    <div className="bg-white rounded-lg shadow-md p-6 mb-8 transition-all hover:shadow-lg">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Comodidades</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {items.map(([icon, label], i) => (
          <div 
            className="flex items-center p-3 rounded-lg transition-all duration-300 hover:bg-gray-50 hover:scale-[1.02]"
            key={i}
          >
            <i className={`${icon} mr-3 text-xl text-baywatch-orange`}></i>
            <span className="text-gray-700">{label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};