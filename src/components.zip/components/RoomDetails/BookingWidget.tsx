import { useEffect, useState } from "react";


export const BookingWidget = () => {
  const [dates, setDates] = useState({
    checkIn: '',
    checkOut: '',
    guests: 2
  });
  
  const [total, setTotal] = useState({
    nights: 0,
    subtotal: 0,
    taxes: 0,
    total: 0
  });

  // Calcular total cuando cambian las fechas
  useEffect(() => {
    if (dates.checkIn && dates.checkOut) {
      const diffTime = Math.abs(new Date(dates.checkOut) - new Date(dates.checkIn));
      const nights = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      const subtotal = nights * 650;
      const taxes = Math.round(subtotal * 0.08);
      
      setTotal({
        nights,
        subtotal,
        taxes,
        total: subtotal + taxes
      });
    }
  }, [dates.checkIn, dates.checkOut]);

  // Validación: fecha de salida posterior a entrada
  const validateDates = (checkIn: string, checkOut: string) => {
    return new Date(checkOut) > new Date(checkIn);
  };

  return (
    <div className="bg-white rounded-lg shadow-xl p-6 sticky top-6 border-t-4 border-red-600 animate-fadeIn">
      {/* Encabezado con precio animado */}
      <div className="flex justify-between items-baseline mb-4">
        <span className="text-4xl font-bold text-baywatch-red hover:scale-105 transition-transform">
          $650
        </span>
        <span className="text-lg text-red-700">/ noche</span>
      </div>
      
      <p className="text-gray-600 text-sm mb-6">Precio promedio por noche, impuestos y tasas no incluidos.</p>
      
      <form action="/reserva" method="GET" className="space-y-4">
        {/* Selector de fechas con validación */}
        <div className="space-y-4">
          <div>
            <label htmlFor="check-in-date" className="block text-gray-700 text-sm font-medium mb-1">
              Fecha de Check-in
            </label>
            <input
              type="date"
              id="check-in-date"
              min={new Date().toISOString().split('T')[0]}
              value={dates.checkIn}
              onChange={(e) => setDates({...dates, checkIn: e.target.value})}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-baywatch-red focus:border-baywatch-red text-gray-800 transition-all"
              required
            />
          </div>
          
          <div>
            <label htmlFor="check-out-date" className="block text-gray-700 text-sm font-medium mb-1">
              Fecha de Check-out
            </label>
            <input
              type="date"
              id="check-out-date"
              min={dates.checkIn || new Date().toISOString().split('T')[0]}
              value={dates.checkOut}
              onChange={(e) => {
                if (validateDates(dates.checkIn, e.target.value)) {
                  setDates({...dates, checkOut: e.target.value});
                }
              }}
              className={`w-full px-3 py-2 border rounded-lg focus:ring-2 text-gray-800 transition-all ${
                dates.checkOut && !validateDates(dates.checkIn, dates.checkOut)
                  ? 'border-red-500 focus:ring-red-300'
                  : 'border-gray-300 focus:ring-baywatch-red focus:border-baywatch-red'
              }`}
              required
            />
            {dates.checkOut && !validateDates(dates.checkIn, dates.checkOut) && (
              <p className="text-red-500 text-xs mt-1">La fecha de salida debe ser posterior</p>
            )}
          </div>
        </div>

        {/* Selector de huéspedes con animación */}
        <div>
          <label htmlFor="num-guests" className="block text-gray-700 text-sm font-medium mb-1">
            Número de Huéspedes
          </label>
          <select
            id="num-guests"
            value={dates.guests}
            onChange={(e) => setDates({...dates, guests: parseInt(e.target.value)})}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-baywatch-red focus:border-baywatch-red text-gray-800 transition-all appearance-none bg-[url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIyNCIgaGVpZ2h0PSIyNCIgdmlld0JveD0iMCAwIDI0IDI0IiBmaWxsPSJub25lIiBzdHJva2U9IiAjd2ViIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PHBvbHlsaW5lIHBvaW50cz0iNiA5IDEyIDE1IDE4IDkiPjwvcG9seWxpbmU+PC9zdmc+')] bg-no-repeat bg-[center_right_0.5rem]"
          >
            {[1, 2, 3, 4].map(n => (
              <option key={n} value={n}>
                {n} Huésped{n > 1 && 'es'}
              </option>
            ))}
          </select>
        </div>

        {/* Resumen de precios con animación */}
        <div className="border-t border-gray-200 pt-4 mt-4 space-y-2">
          <div className="flex justify-between text-gray-700">
            <span>{total.nights} Noche{total.nights !== 1 && 's'} x $650</span>
            <span className="font-medium">${total.subtotal.toLocaleString()}</span>
          </div>
          <div className="flex justify-between text-gray-700">
            <span>Impuestos y Tasas</span>
            <span className="font-medium">${total.taxes.toLocaleString()}</span>
          </div>
          <div className="flex justify-between font-bold text-xl text-gray-900 border-t pt-3 mt-3">
            <span>Total</span>
            <span className="text-baywatch-red">${total.total.toLocaleString()}</span>
          </div>
        </div>

        {/* Botón con efecto de pulsación */}
        <button
          type="submit"
          disabled={!dates.checkIn || !dates.checkOut || !validateDates(dates.checkIn, dates.checkOut)}
          className={`w-full py-3 rounded-lg font-semibold text-lg shadow-md transition-all duration-300 ${
            !dates.checkIn || !dates.checkOut || !validateDates(dates.checkIn, dates.checkOut)
              ? 'bg-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-red-600 to-red-700 text-white cursor-pointer hover:bg-red/90 hover:shadow-lg active:scale-95'
          }`}
        >
          Reservar Ahora
        </button>
      </form>

      {/* Garantía de mejor precio */}
      <div className="mt-4 p-3 bg-gray-50 rounded-lg flex items-start">
        <i className="fas fa-medal text-baywatch-orange mr-2 mt-1"></i>
        <span className="text-sm text-gray-600">
          <strong>Garantía del mejor precio:</strong> Si encuentras este alojamiento más barato, te reembolsamos la diferencia.
        </span>
      </div>
    </div>
  );
};