import { useState } from "react";

export const Reviews = () => {
  const reviews: Reviews[] = [/* tus reviews */];
  const [currentReview, setCurrentReview] = useState(0);

  return (
    <div className="bg-white rounded-lg shadow-md p-6 transition-all hover:shadow-xl">
      <h2 className="text-2xl font-bold mb-6 text-gray-800">Reseñas de Huéspedes</h2>
      
      <div className="relative overflow-hidden min-h-[200px]">
        {reviews.map((r, i) => (
          <div 
            key={i}
            className={`p-4 transition-all duration-500 ${i === currentReview ? 'opacity-100' : 'opacity-0 absolute top-0'}`}
          >
            {/* Contenido de la review */}
          </div>
        ))}
      </div>

      <div className="flex justify-center mt-4 space-x-2">
        {reviews.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentReview(i)}
            className={`w-3 h-3 rounded-full ${i === currentReview ? 'bg-baywatch-red' : 'bg-gray-300'}`}
          />
        ))}
      </div>
    </div>
  );
};