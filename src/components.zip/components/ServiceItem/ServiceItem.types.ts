export interface Service {
  title: string;
  description: string;
}

export interface ServiceItemProps extends Service {}
