interface Service {
  id: string;
  title: string;
  date: string;
  description: string;
  status: string;
  price: string;
  actionText: string;
  isUpcoming?: boolean;
}

export default function ServicesTab() {
  const services: Service[] = [
    {
      id: "1",
      title: "Servicio de Spa: Masaje Relajante",
      date: "20 Nov, 2023",
      description: "Duración: 60 min | Estado: Completado",
      status: "Completado",
      price: "$100.00",
      actionText: "Ver Detalles"
    },
    {
      id: "2",
      title: "Pedido a Habitación: Desayuno Americano",
      date: "16 Nov, 2023",
      description: "Habitación 101 | Estado: Entregado",
      status: "Entregado",
      price: "$25.00",
      actionText: "Reordenar"
    },
    {
      id: "3",
      title: "Reserva de Restaurante: Cena en \"El Faro\"",
      date: "Próximo: 25 Dic, 2023 - 20:00h",
      description: "2 personas | Mesa con vista al mar",
      status: "Confirmada",
      price: "Confirmada",
      actionText: "Modificar Reserva",
      isUpcoming: true
    }
  ];

  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-900 mb-6">Mis Servicios y Pedidos Recientes</h3>
      <ul className="space-y-4">
        {services.map((service) => (
          <ServiceItem key={service.id} service={service} />
        ))}
      </ul>
    </div>
  );
}

interface ServiceItemProps {
  service: Service;
}

function ServiceItem({ service }: ServiceItemProps) {
  return (
    <li className={`rounded-lg p-4 ${
      service.isUpcoming ? 'border-2 border-baywatch-orange bg-orange-50' : 'border border-gray-200'
    }`}>
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-semibold text-gray-900">{service.title}</h4>
        <span className={`text-sm ${
          service.isUpcoming ? 'text-baywatch-orange' : 'text-gray-500'
        }`}>
          {service.date}
        </span>
      </div>
      <p className="text-sm text-gray-700 mb-2">{service.description}</p>
      <div className="flex justify-between items-center">
        <span className={`font-bold ${
          service.isUpcoming ? 'text-gray-900' : 'text-gray-900'
        }`}>
          {service.price}
        </span>
        <button className="text-baywatch-red hover:underline text-sm">
          {service.actionText}
        </button>
      </div>
    </li>
  );
}