interface UserHeaderProps {
  name: string;
  memberSince: string;
  membershipLevel: string;
  avatar: string;
  isVerified: boolean;
}

export default function UserHeader({
  name,
  memberSince,
  membershipLevel,
  avatar,
  isVerified
}: UserHeaderProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="relative">
            <img 
              src={avatar} 
              alt={name}
              className="h-20 w-20 rounded-full object-cover border-4 border-baywatch-orange"
            />
            {isVerified && (
              <div className="absolute -bottom-1 -right-1 bg-green-500 h-6 w-6 rounded-full border-2 border-white flex items-center justify-center">
                <i className="fas fa-check text-white text-xs"></i>
              </div>
            )}
          </div>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Hola {name}</h1>
            <p className="text-gray-600">Bienvenida de vuelta <span className="text-2xl">👋</span></p>
            <p className="text-sm text-gray-500 mt-1">Miembro desde {memberSince}</p>
          </div>
        </div>
        <div className="text-right">
          <div className="bg-gradient-to-r from-baywatch-red to-baywatch-orange text-white px-4 py-2 rounded-lg">
            <p className="text-sm font-medium">Estado VIP</p>
            <p className="text-lg font-bold">{membershipLevel}</p>
          </div>
        </div>
      </div>
    </div>
  );
}