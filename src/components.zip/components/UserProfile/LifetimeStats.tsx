interface LifetimeStatsProps {
  totalStays: number;
  totalNights: number;
  totalPointsEarned: number;
  benefitsRedeemed: string;
}

export default function LifetimeStats({
  totalStays,
  totalNights,
  totalPointsEarned,
  benefitsRedeemed
}: LifetimeStatsProps) {
  return (
    <div className="bg-white rounded-lg shadow-sm p-6">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Estadísticas de Vida</h3>
      <div className="space-y-4">
        <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
          <div className="bg-yellow-100 p-2 rounded-lg">
            <i className="fas fa-bed text-yellow-600"></i>
          </div>
          <div>
            <p className="text-sm text-gray-600">Total de Estancias</p>
            <p className="font-bold text-gray-900">{totalStays}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
          <div className="bg-blue-100 p-2 rounded-lg">
            <i className="fas fa-calendar-check text-blue-600"></i>
          </div>
          <div>
            <p className="text-sm text-gray-600">Noches Totales</p>
            <p className="font-bold text-gray-900">{totalNights}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
          <div className="bg-green-100 p-2 rounded-lg">
            <i className="fas fa-star text-green-600"></i>
          </div>
          <div>
            <p className="text-sm text-gray-600">Puntos Ganados</p>
            <p className="font-bold text-gray-900">{totalPointsEarned.toLocaleString()}</p>
          </div>
        </div>
        <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
          <div className="bg-purple-100 p-2 rounded-lg">
            <i className="fas fa-gift text-purple-600"></i>
          </div>
          <div>
            <p className="text-sm text-gray-600">Beneficios Canjeados</p>
            <p className="font-bold text-gray-900">{benefitsRedeemed}</p>
          </div>
        </div>
      </div>
    </div>
  );
}