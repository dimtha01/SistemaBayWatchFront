export type TabName = 'reservas' | 'servicios' | 'contrasenia' | 'informacion';

interface TabNavigationProps {
  activeTab: TabName;
  onTabChange: (tab: TabName) => void;
}

export default function TabNavigation({ 
  activeTab, 
  onTabChange 
}: TabNavigationProps) {
  const tabs = [
    { id: 'reservas', label: 'Mis Reservas Recientes' },
    { id: 'servicios', label: 'Servicios/Pedidos Recientes' },
    { id: 'contrasenia', label: 'Contraseña' },
    { id: 'informacion', label: 'Información de Usuario' }
  ];

  return (
    <div className="border-b border-gray-200 mb-6">
      <div className="flex space-x-8 px-6 pt-4">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            className={`text-lg font-medium pb-4 border-b-2 focus:outline-none ${
              activeTab === tab.id
                ? 'text-baywatch-red font-semibold border-baywatch-red'
                : 'text-gray-600 border-transparent hover:border-gray-300'
            }`}
            onClick={() => onTabChange(tab.id as TabName)}
          >
            {tab.label}
          </button>
        ))}
      </div>
    </div>
  );
}