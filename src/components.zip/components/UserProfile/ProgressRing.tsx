interface ProgressRingProps {
  percentage: number;
}

export default function ProgressRing({ percentage }: ProgressRingProps) {
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;

  return (
    <div className="mt-6 flex items-center justify-center">
      <div className="relative w-32 h-32">
        <svg className="w-32 h-32 transform -rotate-90" viewBox="0 0 120 120">
          <circle 
            cx="60" 
            cy="60" 
            r={radius} 
            stroke="#E5E7EB" 
            strokeWidth="8" 
            fill="none" 
          />
          <circle 
            cx="60" 
            cy="60" 
            r={radius} 
            stroke="#F97316" 
            strokeWidth="8" 
            fill="none"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            strokeLinecap="round" 
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className="text-2xl font-bold text-baywatch-orange">{percentage}%</span>
          <span className="text-xs text-gray-500">Próximo nivel</span>
        </div>
      </div>
    </div>
  );
}