interface RewardsBalanceProps {
  points: number;
  spaCredits: string;
  discounts: string;
  availableToSpend: string;
}

export default function RewardsBalance({
  points,
  spaCredits,
  discounts,
  availableToSpend
}: RewardsBalanceProps) {
  return (
    <div>
      <h3 className="text-lg font-semibold text-gray-900 mb-4">Balance de Recompensas</h3>
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Puntos BayWatch</span>
          <span className="font-semibold text-baywatch-red">{points.toLocaleString()}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Créditos de Spa</span>
          <span className="font-semibold text-baywatch-red">{spaCredits}</span>
        </div>
        <div className="flex justify-between items-center">
          <span className="text-sm text-gray-600">Descuentos Disponibles</span>
          <span className="font-semibold text-baywatch-red">{discounts}</span>
        </div>
        <div className="flex justify-between items-center border-t pt-3">
          <span className="text-sm font-medium text-gray-900">Disponible para Gastar</span>
          <span className="font-bold text-baywatch-red text-lg">{availableToSpend}</span>
        </div>
      </div>
    </div>
  );
}