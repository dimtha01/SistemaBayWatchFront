interface Reservation {
  id: string;
  roomType: string;
  roomImage: string;
  description: string;
  rating?: number;
  review?: string;
  status: 'confirmed' | 'completed' | 'upcoming';
}

interface ReservationsTabProps {
  reservations: Reservation[];
}

export default function ReservationsTab({ reservations }: ReservationsTabProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-gray-900">Mis Reservas Recientes</h3>
        <div className="flex items-center space-x-2">
          <input 
            type="text" 
            placeholder="Buscar reservas..."
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm"
          />
          <select className="px-3 py-2 border border-gray-300 rounded-lg text-sm">
            <option>Últimos 6 meses</option>
            <option>Este año</option>
            <option>Todo el historial</option>
          </select>
        </div>
      </div>
      
      {reservations.map((reservation) => (
        <ReservationItem key={reservation.id} reservation={reservation} />
      ))}
    </div>
  );
}

interface ReservationItemProps {
  reservation: Reservation;
}

function ReservationItem({ reservation }: ReservationItemProps) {
  const isUpcoming = reservation.status === 'upcoming';
  
  return (
    <div className={`rounded-lg p-4 mb-4 ${
      isUpcoming ? 'border-2 border-baywatch-orange bg-orange-50' : 'border border-gray-200'
    }`}>
      {isUpcoming && (
        <div className="flex items-center mb-2">
          <i className="fas fa-clock text-baywatch-orange mr-2"></i>
          <span className="text-sm font-medium text-baywatch-orange">Próxima Reserva</span>
        </div>
      )}
      
      <div className="flex items-start justify-between">
        <div className="flex space-x-4">
          <img 
            src={reservation.roomImage}
            alt={reservation.roomType}
            className="w-20 h-16 object-cover rounded-lg"
          />
          <div>
            <h4 className="font-semibold text-gray-900">{reservation.roomType}</h4>
            <p className="text-sm text-gray-600 mt-1">{reservation.description}</p>
            
            {reservation.rating && (
              <div className="flex items-center mt-2">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <i 
                      key={i} 
                      className={`fas fa-star ${
                        i < reservation.rating! ? 'text-yellow-400' : 'text-gray-300'
                      }`}
                    ></i>
                  ))}
                </div>
                <span className="ml-2 text-sm font-medium text-gray-900">{reservation.rating}.0</span>
              </div>
            )}
            
            {isUpcoming && (
              <div className="flex items-center mt-2 space-x-4">
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full text-xs font-medium">
                  Confirmada
                </span>
                <span className="text-xs text-gray-500">Check-in en 12 días</span>
              </div>
            )}
          </div>
        </div>
        
        <div className="flex space-x-2">
          {!isUpcoming && (
            <button className="bg-gray-100 hover:bg-gray-200 px-4 py-2 rounded-lg text-sm font-medium">
              <i className="fas fa-share-alt mr-2"></i>Compartir Experiencia
            </button>
          )}
          
          {isUpcoming ? (
            <>
              <button className="bg-baywatch-red hover:bg-baywatch-red/90 text-white px-4 py-2 rounded-lg text-sm font-medium">
                Ver Reserva
              </button>
              <button className="bg-white border border-gray-300 hover:bg-gray-50 px-4 py-2 rounded-lg text-sm font-medium">
                Modificar
              </button>
            </>
          ) : (
            <div className="flex space-x-4">
              <button className="text-baywatch-red hover:text-baywatch-red/80">Reservar de nuevo</button>
              <button className="text-gray-600 hover:text-gray-800">Ver detalles</button>
            </div>
          )}
        </div>
      </div>
      
      {reservation.review && (
        <div className="mt-4 p-3 bg-gray-50 rounded-lg">
          <p className="text-sm text-gray-700">{reservation.review}</p>
        </div>
      )}
      
      {!isUpcoming && (
        <div className="mt-3 flex items-center justify-between text-sm text-gray-500">
          <span>Reseña verificada • Estancia confirmada</span>
        </div>
      )}
    </div>
  );
}